# UPSJB_DRAFFI

Sistema Web para la Gestión de Ventas, Pedidos e Inventario del Restaurante D'RAFFI
(LRPD 01 – Ingeniería de Software, UPSJB).

## Estructura

```
UPSJB_DRAFFI/
├── docs/uml/        Diagramas UML (DCU, DCLASS, DACTIVITY, DSECUENCE, DCOMPONENT, DCOMUNICACTION)
├── prototipo/       Prototipo HTML de las pantallas
└── sistema/         Aplicación Laravel (MVC)
    ├── app/Models/  Role, User, Plato, Insumo, Pedido, DetallePedido, Venta, Comprobante, MovimientoInsumo
    └── database/    migrations, factories, seeders
```

## Puesta en marcha

```sh
cd sistema
composer install
php artisan key:generate
# crear la base de datos "draffi" en MySQL (ver .env)
php artisan migrate:fresh --seed
php artisan serve
```

Usuarios iniciales (contraseña `password`): `admin`, `mesero`, `cajero`.

## Modelo de datos

| Tabla | Requerimientos |
|---|---|
| roles, users | RF01, RF02, RNF01, RNF02 |
| platos | RF03 – RF05 |
| pedidos, detalle_pedidos | RF06 – RF09 |
| ventas, comprobantes | RF10 – RF12 |
| insumos, movimiento_insumos | RF13 – RF15 |

Las alertas (RF15) y los reportes (RF16) se obtienen por consulta con los scopes
`Insumo::stockBajo()` e `Insumo::proximosAVencer()`.
