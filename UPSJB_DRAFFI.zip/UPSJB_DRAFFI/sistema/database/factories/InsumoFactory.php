<?php

namespace Database\Factories;

use App\Models\Insumo;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Insumo>
 */
class InsumoFactory extends Factory
{
    public function definition(): array
    {
        return [
            'nombre' => fake()->unique()->words(2, true),
            'unidad_medida' => fake()->randomElement(['kg', 'lt', 'unidad']),
            'stock' => fake()->randomFloat(2, 10, 50),
            'stock_minimo' => 5,
            'fecha_vencimiento' => now()->addDays(fake()->numberBetween(10, 90))->toDateString(),
            'activo' => true,
        ];
    }

    public function stockBajo(): static
    {
        return $this->state(fn () => ['stock' => 2, 'stock_minimo' => 5]);
    }

    public function porVencer(int $dias = 3): static
    {
        return $this->state(fn () => ['fecha_vencimiento' => now()->addDays($dias)->toDateString()]);
    }
}
