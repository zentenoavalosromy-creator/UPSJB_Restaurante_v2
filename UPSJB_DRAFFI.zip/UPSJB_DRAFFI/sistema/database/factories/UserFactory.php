<?php

namespace Database\Factories;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/**
 * @extends Factory<User>
 */
class UserFactory extends Factory
{
    /**
     * The current password being used by the factory.
     */
    protected static ?string $password;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'rol_id' => fn () => Role::firstOrCreate(['nombre' => Role::MESERO])->id,
            'name' => fake()->name(),
            'username' => fake()->unique()->userName(),
            'dni' => fake()->unique()->numerify('########'),
            'phone' => fake()->numerify('9########'),
            'activo' => true,
            'email' => fake()->unique()->safeEmail(),
            'email_verified_at' => now(),
            'password' => static::$password ??= Hash::make('password'),
            'remember_token' => Str::random(10),
        ];
    }

    public function administrador(): static
    {
        return $this->state(fn () => [
            'rol_id' => Role::firstOrCreate(['nombre' => Role::ADMINISTRADOR])->id,
        ]);
    }

    public function cajero(): static
    {
        return $this->state(fn () => [
            'rol_id' => Role::firstOrCreate(['nombre' => Role::CAJERO])->id,
        ]);
    }

    /**
     * Indicate that the model's email address should be unverified.
     */
    public function unverified(): static
    {
        return $this->state(fn (array $attributes) => [
            'email_verified_at' => null,
        ]);
    }
}
