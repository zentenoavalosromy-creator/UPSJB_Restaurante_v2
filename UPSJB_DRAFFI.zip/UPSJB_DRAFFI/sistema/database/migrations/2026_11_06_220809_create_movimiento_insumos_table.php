<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * RF13: historial de entradas y salidas de insumos (control de existencias,
     * tratado en el Acta de Reunión N.° 3).
     * Tipos: entrada, salida, ajuste, baja.
     */
    public function up(): void
    {
        Schema::create('movimiento_insumos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('insumo_id')->constrained()->restrictOnDelete();
            $table->foreignId('user_id')->constrained()->restrictOnDelete();
            $table->string('tipo', 10);
            $table->decimal('cantidad', 10, 2);
            $table->string('motivo')->nullable();
            $table->timestamps();

            $table->index(['insumo_id', 'created_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('movimiento_insumos');
    }
};
