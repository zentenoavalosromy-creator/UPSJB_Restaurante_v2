<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * RF13, RF14, RF15: insumos con stock, stock mínimo y fecha de vencimiento.
     * Los nombres 'stock', 'stock_minimo' y 'fecha_vencimiento' coinciden con
     * las consultas SQL del punto 3.6.5 del LRPD.
     * "Dar de baja" un insumo = activo false.
     */
    public function up(): void
    {
        Schema::create('insumos', function (Blueprint $table) {
            $table->id();
            $table->string('nombre', 120);
            $table->string('unidad_medida', 20)->default('unidad'); // kg, lt, unidad...
            $table->decimal('stock', 10, 2)->default(0);
            $table->decimal('stock_minimo', 10, 2)->default(0);
            $table->date('fecha_vencimiento')->nullable()->index();
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('insumos');
    }
};
