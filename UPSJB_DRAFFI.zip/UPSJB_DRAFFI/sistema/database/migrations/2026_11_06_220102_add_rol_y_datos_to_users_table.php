<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * RF01: inicio de sesión con usuario y contraseña.
     * RF02: usuarios con rol asignado.
     * RNF01: la contraseña se guarda cifrada (cast 'hashed' en el modelo User).
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->foreignId('rol_id')->after('id')->constrained('roles')->restrictOnDelete();
            $table->string('username', 50)->unique()->after('name');
            $table->char('dni', 8)->unique()->after('username');
            $table->string('phone', 15)->nullable()->after('dni');
            $table->boolean('activo')->default(true)->after('phone');

            // El login es por usuario, por eso el correo pasa a ser opcional.
            $table->string('email')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropConstrainedForeignId('rol_id');
            $table->dropUnique(['username']);
            $table->dropUnique(['dni']);
            $table->dropColumn(['username', 'dni', 'phone', 'activo']);
            $table->string('email')->nullable(false)->change();
        });
    }
};
