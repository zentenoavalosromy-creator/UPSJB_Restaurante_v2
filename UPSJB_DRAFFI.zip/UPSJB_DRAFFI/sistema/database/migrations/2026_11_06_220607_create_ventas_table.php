<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * RF10, RF12: venta generada a partir de un pedido (relación 1 a 0..1).
     * Estados: registrada, anulada.
     */
    public function up(): void
    {
        Schema::create('ventas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pedido_id')->unique()->constrained()->restrictOnDelete();
            $table->foreignId('user_id')->constrained()->restrictOnDelete(); // cajero que cobra
            $table->dateTime('fecha');
            $table->decimal('monto_total', 10, 2);
            $table->string('metodo_pago', 20)->default('efectivo'); // efectivo, yape, tarjeta...
            $table->string('estado', 20)->default('registrada')->index();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ventas');
    }
};
