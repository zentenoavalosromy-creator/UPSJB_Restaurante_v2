<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * RF06 a RF09: pedidos registrados por un mesero.
     * Estados (RF09): registrado, en_preparacion, atendido, pagado, anulado.
     */
    public function up(): void
    {
        Schema::create('pedidos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->restrictOnDelete(); // mesero que registra
            $table->string('mesa', 10)->nullable();
            $table->dateTime('fecha');
            $table->string('estado', 20)->default('registrado')->index();
            $table->decimal('total', 10, 2)->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pedidos');
    }
};
