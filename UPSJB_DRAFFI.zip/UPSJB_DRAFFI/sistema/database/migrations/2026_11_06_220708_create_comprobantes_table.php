<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * RF11: comprobante de venta NO electrónico (sin conexión a SUNAT).
     */
    public function up(): void
    {
        Schema::create('comprobantes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('venta_id')->unique()->constrained()->restrictOnDelete();
            $table->string('tipo', 20)->default('ticket');
            $table->char('serie', 4);
            $table->unsignedInteger('numero');
            $table->dateTime('fecha_emision');
            $table->timestamps();

            $table->unique(['serie', 'numero']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('comprobantes');
    }
};
