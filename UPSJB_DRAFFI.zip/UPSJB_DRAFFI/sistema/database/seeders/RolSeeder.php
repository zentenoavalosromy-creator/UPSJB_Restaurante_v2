<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Seeder;

class RolSeeder extends Seeder
{
    /**
     * RF02: roles del sistema.
     */
    public function run(): void
    {
        $roles = [
            Role::ADMINISTRADOR => 'Gestiona usuarios, platos, inventario, alertas y reportes.',
            Role::MESERO => 'Registra pedidos, los consulta y cambia su estado.',
            Role::CAJERO => 'Registra ventas, emite comprobantes y consulta el historial.',
        ];

        foreach ($roles as $nombre => $descripcion) {
            Role::updateOrCreate(['nombre' => $nombre], ['descripcion' => $descripcion]);
        }
    }
}
