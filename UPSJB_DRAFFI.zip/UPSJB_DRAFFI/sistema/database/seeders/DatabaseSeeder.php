<?php

namespace Database\Seeders;

use App\Models\Insumo;
use App\Models\Plato;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     * Contraseña inicial de los 3 usuarios: "password" (cámbiala al desplegar).
     */
    public function run(): void
    {
        $this->call(RolSeeder::class);

        $usuarios = [
            [Role::ADMINISTRADOR, 'Administrador D\'RAFFI', 'admin', '10000001'],
            [Role::MESERO, 'Mesero de prueba', 'mesero', '10000002'],
            [Role::CAJERO, 'Cajero de prueba', 'cajero', '10000003'],
        ];

        foreach ($usuarios as [$rol, $nombre, $username, $dni]) {
            User::updateOrCreate(
                ['username' => $username],
                [
                    'rol_id' => Role::where('nombre', $rol)->value('id'),
                    'name' => $nombre,
                    'dni' => $dni,
                    'activo' => true,
                    'password' => 'password', // se cifra con el cast 'hashed'
                ]
            );
        }

        $platos = [
            ['Ají de gallina', 'Pechuga deshilachada en crema de ají amarillo, con arroz.', 18.00],
            ['Lomo saltado', 'Lomo fino salteado con cebolla, tomate y papas fritas.', 22.00],
            ['Arroz con pollo', 'Arroz verde con presa de pollo y ensalada criolla.', 15.00],
            ['Tallarines verdes', 'Tallarines con salsa de albahaca y bistec.', 17.00],
            ['Chicha morada (jarra)', 'Jarra de chicha morada de 1 litro.', 8.00],
        ];

        foreach ($platos as [$nombre, $descripcion, $precio]) {
            Plato::updateOrCreate(
                ['nombre' => $nombre],
                ['descripcion' => $descripcion, 'precio' => $precio, 'disponible' => true]
            );
        }

        $insumos = [
            // nombre, unidad, stock, stock mínimo, días para vencer (null = no vence pronto)
            ['Arroz', 'kg', 25, 5, null],
            ['Pechuga de pollo', 'kg', 4, 6, 3],   // stock bajo y por vencer
            ['Lomo de res', 'kg', 8, 3, 5],
            ['Ají amarillo', 'kg', 3, 2, 4],
            ['Aceite vegetal', 'lt', 12, 4, 120],
        ];

        foreach ($insumos as [$nombre, $unidad, $stock, $minimo, $dias]) {
            Insumo::updateOrCreate(
                ['nombre' => $nombre],
                [
                    'unidad_medida' => $unidad,
                    'stock' => $stock,
                    'stock_minimo' => $minimo,
                    'fecha_vencimiento' => $dias ? now()->addDays($dias)->toDateString() : null,
                    'activo' => true,
                ]
            );
        }
    }
}
