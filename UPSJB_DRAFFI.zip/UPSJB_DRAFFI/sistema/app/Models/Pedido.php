<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use InvalidArgumentException;

#[Fillable(['user_id', 'mesa', 'fecha', 'estado', 'total'])]
class Pedido extends Model
{
    // RF09: estados del pedido
    public const REGISTRADO = 'registrado';
    public const EN_PREPARACION = 'en_preparacion';
    public const ATENDIDO = 'atendido';
    public const PAGADO = 'pagado';
    public const ANULADO = 'anulado';

    public const ESTADOS = [
        self::REGISTRADO,
        self::EN_PREPARACION,
        self::ATENDIDO,
        self::PAGADO,
        self::ANULADO,
    ];

    protected function casts(): array
    {
        return [
            'fecha' => 'datetime',
            'total' => 'decimal:2',
        ];
    }

    /** Mesero que registró el pedido. */
    public function mesero(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function detalles(): HasMany
    {
        return $this->hasMany(DetallePedido::class);
    }

    public function venta(): HasOne
    {
        return $this->hasOne(Venta::class);
    }

    // Método del diagrama: +cambiarEstado()  (RF09)
    public function cambiarEstado(string $estado): void
    {
        if (! in_array($estado, self::ESTADOS, true)) {
            throw new InvalidArgumentException("Estado de pedido no válido: {$estado}");
        }

        $this->update(['estado' => $estado]);
    }

    // Método del diagrama: +calcularTotal()  (RF07)
    public function calcularTotal(): float
    {
        $total = round((float) $this->detalles()->sum('subtotal'), 2);
        $this->update(['total' => $total]);

        return $total;
    }
}
