<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable(['pedido_id', 'plato_id', 'cantidad', 'precio_unitario', 'subtotal'])]
class DetallePedido extends Model
{
    protected function casts(): array
    {
        return [
            'cantidad' => 'integer',
            'precio_unitario' => 'decimal:2',
            'subtotal' => 'decimal:2',
        ];
    }

    protected static function booted(): void
    {
        // RF07: el subtotal y el total del pedido se calculan solos.
        static::saving(function (DetallePedido $detalle) {
            $detalle->subtotal = $detalle->calcularSubtotal();
        });

        static::saved(fn (DetallePedido $detalle) => $detalle->pedido->calcularTotal());
        static::deleted(fn (DetallePedido $detalle) => $detalle->pedido->calcularTotal());
    }

    public function pedido(): BelongsTo
    {
        return $this->belongsTo(Pedido::class);
    }

    public function plato(): BelongsTo
    {
        return $this->belongsTo(Plato::class);
    }

    // Método del diagrama: +calcularSubtotal()
    public function calcularSubtotal(): float
    {
        return round($this->cantidad * (float) $this->precio_unitario, 2);
    }
}
