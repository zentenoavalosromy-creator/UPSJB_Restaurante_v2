<?php

namespace App\Models;

use Database\Factories\PlatoFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable(['nombre', 'descripcion', 'precio', 'disponible'])]
class Plato extends Model
{
    /** @use HasFactory<PlatoFactory> */
    use HasFactory;

    protected function casts(): array
    {
        return [
            'precio' => 'decimal:2',
            'disponible' => 'boolean',
        ];
    }

    public function detalles(): HasMany
    {
        return $this->hasMany(DetallePedido::class);
    }

    /** RF05: carta de platos disponibles. */
    public function scopeDisponibles(Builder $query): Builder
    {
        return $query->where('disponible', true);
    }

    // Método del diagrama: +modificarPrecio()  (RF04)
    public function modificarPrecio(float $precio): void
    {
        $this->update(['precio' => $precio]);
    }
}
