<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** RF11: comprobante de venta NO electrónico (sin conexión a SUNAT). */
#[Fillable(['venta_id', 'tipo', 'serie', 'numero', 'fecha_emision'])]
class Comprobante extends Model
{
    protected function casts(): array
    {
        return [
            'numero' => 'integer',
            'fecha_emision' => 'datetime',
        ];
    }

    public function venta(): BelongsTo
    {
        return $this->belongsTo(Venta::class);
    }

    /** Ej.: T001-000045 */
    public function getCodigoAttribute(): string
    {
        return sprintf('%s-%06d', $this->serie, $this->numero);
    }
}
