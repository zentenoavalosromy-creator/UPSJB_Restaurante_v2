<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

#[Fillable(['pedido_id', 'user_id', 'fecha', 'monto_total', 'metodo_pago', 'estado'])]
class Venta extends Model
{
    public const REGISTRADA = 'registrada';
    public const ANULADA = 'anulada';

    protected function casts(): array
    {
        return [
            'fecha' => 'datetime',
            'monto_total' => 'decimal:2',
        ];
    }

    public function pedido(): BelongsTo
    {
        return $this->belongsTo(Pedido::class);
    }

    /** Cajero que cobró la venta. */
    public function cajero(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function comprobante(): HasOne
    {
        return $this->hasOne(Comprobante::class);
    }

    // Método del diagrama: +consultarHistorial()  (RF12)
    public function scopeHistorial(Builder $query): Builder
    {
        return $query->latest('fecha');
    }

    /** RF12: anular una venta. */
    public function anular(): void
    {
        $this->update(['estado' => self::ANULADA]);
    }
}
