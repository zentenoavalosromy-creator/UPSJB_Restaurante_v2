<?php

namespace App\Models;

use Database\Factories\InsumoFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

#[Fillable(['nombre', 'unidad_medida', 'stock', 'stock_minimo', 'fecha_vencimiento', 'activo'])]
class Insumo extends Model
{
    /** @use HasFactory<InsumoFactory> */
    use HasFactory;

    public const ENTRADA = 'entrada';
    public const SALIDA = 'salida';
    public const AJUSTE = 'ajuste';
    public const BAJA = 'baja';

    protected function casts(): array
    {
        return [
            'stock' => 'decimal:2',
            'stock_minimo' => 'decimal:2',
            'fecha_vencimiento' => 'date',
            'activo' => 'boolean',
        ];
    }

    public function movimientos(): HasMany
    {
        return $this->hasMany(MovimientoInsumo::class);
    }

    public function scopeActivos(Builder $query): Builder
    {
        return $query->where('activo', true);
    }

    /** RF15: stock igual o menor al mínimo. */
    public function scopeStockBajo(Builder $query): Builder
    {
        return $query->whereColumn('stock', '<=', 'stock_minimo');
    }

    /** RF15: insumos que vencen dentro de $dias días (incluye los ya vencidos). */
    public function scopeProximosAVencer(Builder $query, int $dias = 7): Builder
    {
        return $query->whereNotNull('fecha_vencimiento')
            ->whereDate('fecha_vencimiento', '<=', now()->addDays($dias)->toDateString());
    }

    // Método del diagrama: +consultarStock()  (RF14)
    public function consultarStock(): float
    {
        return (float) $this->stock;
    }

    // Método del diagrama: +actualizarCantidad()  (RF13)
    // Registra el movimiento y actualiza el stock en una sola transacción.
    public function actualizarCantidad(string $tipo, float $cantidad, int $userId, ?string $motivo = null): void
    {
        if ($cantidad < 0) {
            throw new InvalidArgumentException('La cantidad no puede ser negativa.');
        }

        DB::transaction(function () use ($tipo, $cantidad, $userId, $motivo) {
            $actual = (float) $this->stock;

            $nuevo = match ($tipo) {
                self::ENTRADA => $actual + $cantidad,
                self::SALIDA, self::BAJA => $actual - $cantidad,
                self::AJUSTE => $cantidad,
                default => throw new InvalidArgumentException("Tipo de movimiento no válido: {$tipo}"),
            };

            if ($nuevo < 0) {
                throw new InvalidArgumentException('El stock disponible es insuficiente.');
            }

            $this->movimientos()->create([
                'user_id' => $userId,
                'tipo' => $tipo,
                'cantidad' => $cantidad,
                'motivo' => $motivo,
            ]);

            $this->update(['stock' => $nuevo]);
        });
    }

    /** RF13: dar de baja un insumo. */
    public function darDeBaja(): void
    {
        $this->update(['activo' => false]);
    }
}
